<?php
namespace Components\BootstrapSlider\Models;

use Illuminate\Database\Eloquent\Model;

class Bootstrapslider extends Model
{
    protected $fillable = ['title','slider'];
}
